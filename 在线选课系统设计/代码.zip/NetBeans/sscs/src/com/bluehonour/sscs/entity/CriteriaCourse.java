/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bluehonour.sscs.entity;

/**
 *
 * @author 需玩玩
 */
public class CriteriaCourse {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String cno;
	private String tno;
	
	public String getCno() {
		return cno;
	}
	public void setCno(String cno) {
		this.cno = cno;
	}
	public String getTno() {
		return tno;
	}
	public void setTno(String tno) {
		this.tno = tno;
	}
	
	public CriteriaCourse(String cno, String tno) {
		super();
		this.cno = cno;
		this.tno = tno;
	}
        
	public CriteriaCourse() {
	}
	@Override
	public String toString() {
		return "CriteriaCourse [cno=" + cno + ", tno=" + tno + "]";
	}
}
