/*
 Navicat Premium Data Transfer

 Source Server         : local
 Source Server Type    : MySQL
 Source Server Version : 50130
 Source Host           : localhost:3306
 Source Schema         : sscs

 Target Server Type    : MySQL
 Target Server Version : 50130
 File Encoding         : 65001

 Date: 13/07/2021 09:40:48
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for 22
-- ----------------------------
DROP TABLE IF EXISTS `22`;
CREATE TABLE `22`  (
  `ss` varchar(255) CHARACTER SET armscii8 COLLATE armscii8_general_ci NOT NULL,
  `hh` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

SET FOREIGN_KEY_CHECKS = 1;
