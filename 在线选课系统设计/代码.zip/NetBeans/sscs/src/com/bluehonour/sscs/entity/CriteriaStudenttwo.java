package com.bluehonour.sscs.entity;

public class CriteriaStudenttwo {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String sno;
	private String sname;
	private String cname;
	private String classno;
	private String periodstart;
	public String getSno() {
		return sno;
	}
	public void setSno(String sno) {
		this.sno = sno;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getClassno() {
		return classno;
	}
	public void setClassno(String classno) {
		this.classno = classno;
	}
	public String getPeriodstart() {
		return periodstart;
	}
	public void setPeriodstart(String periodstart) {
		this.periodstart = periodstart;
	}
	public CriteriaStudenttwo(String sno, String sname, String cname, String classno, String periodstart) {
		super();
		this.sno = sno;
		this.sname = sname;
		this.cname = cname;
		this.classno = classno;
		this.periodstart = periodstart;
	}

	public CriteriaStudenttwo() {
	}
	@Override
	public String toString() {
		return "CriteriaStudenttwo [sno=" + sno + ", sname=" + sname + ", cname=" + cname + ", classno=" + classno
				+ ", periodstart=" + periodstart + "]";
	}
	
}
