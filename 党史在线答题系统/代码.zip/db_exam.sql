/*
SQLyog v10.2 
MySQL - 5.5.53 : Database - db_exam
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_exam` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `db_exam`;

/*Table structure for table `tb_lesson` */

DROP TABLE IF EXISTS `tb_lesson`;

CREATE TABLE `tb_lesson` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(60) DEFAULT NULL,
  `JoinTime` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

/*Data for the table `tb_lesson` */

INSERT INTO `tb_lesson` VALUES (8, '党史-个人', '2021-12-19 00:00:00');
INSERT INTO `tb_lesson` VALUES (29, '党史-团队', '2021-12-19 00:00:00');


/*Table structure for table `tb_manager` */

DROP TABLE IF EXISTS `tb_manager`;

CREATE TABLE `tb_manager` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `PWD` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `tb_manager` */

insert  into `tb_manager`(`ID`,`name`,`PWD`) values (1,'admin','admin'),(2,'tf111','tf111');

/*Table structure for table `tb_questions` */

DROP TABLE IF EXISTS `tb_questions`;

CREATE TABLE `tb_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(50) DEFAULT NULL,
  `type` char(6) DEFAULT NULL,
  `joinTime` datetime DEFAULT NULL,
  `lessonId` int(11) DEFAULT NULL,
  `taoTiId` int(11) DEFAULT NULL,
  `optionA` varchar(50) DEFAULT NULL,
  `optionB` varchar(50) DEFAULT NULL,
  `optionC` varchar(50) DEFAULT NULL,
  `optionD` varchar(50) DEFAULT NULL,
  `answer` varchar(10) DEFAULT NULL,
  `note` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;

/*Data for the table `tb_questions` */

insert  into `tb_questions`(`id`,`subject`,`type`,`joinTime`,`lessonId`,`taoTiId`,`optionA`,`optionB`,`optionC`,`optionD`,`answer`,`note`) values (39, '中共一大在哪里召开？', '单选题', '2015-12-1 00:00:00', 29, 17, '上海', '天津', '北京', '南京', 'A', '空'), (40, '被称为中国共产党历史上的两个伟大转折点是？', '多选题', '2015-12-1 00:00:00', 29, 17, '八七会议', '遵义会议', '十一届三中全会', '九一会议', 'B,C', '空'), (48, '中国共产党成立于多少年？', '单选题', '2021-12-19 00:00:00', 8, 19, '1919', '1920', '1921', '以上都不是', 'C', ''), (49, '1941年，中国共产党先后提出了巩固解放区的十大基本政策，其中心是？', '多选题', '2021-12-19 00:00:00', 8, 19, '开展大生产运动', '建立三三制政权', '整顿三风', '农民教育', 'A,C', '');
/*Table structure for table `tb_student` */

DROP TABLE IF EXISTS `tb_student`;

CREATE TABLE `tb_student` (
  `ID` varchar(16) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `pwd` varchar(20) DEFAULT NULL,
  `sex` varchar(2) DEFAULT NULL,
  `joinTime` datetime DEFAULT NULL,
  `question` varchar(50) DEFAULT NULL,
  `answer` varchar(50) DEFAULT NULL,
  `profession` varchar(30) DEFAULT NULL,
  `cardNo` varchar(18) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tb_student` */

insert  into `tb_student`(`ID`,`name`,`pwd`,`sex`,`joinTime`,`question`,`answer`,`profession`,`cardNo`) values ('CN20151201000001','王大锤','111','男','2015-12-01 00:00:00','birthday','717','广告学','220198302********'),('CN20151201000002','何小花','111','女','2015-12-01 00:00:00','birthday','1','计算机应用软件','220198007********'),('CN20151225000005','戴小超','111111','女','2015-12-01 00:00:00','我最喜欢的颜色','蓝灰色','计算机应用软件','220104************'),('CN20151229000006','熊时雨','000','男','2015-12-01 00:00:00','你好','你好','公司管理','20020'),('CN20151229000007','朱培','111111','男','2015-12-01 00:00:00','你好','你好','编程','52200');

/*Table structure for table `tb_sturesult` */

DROP TABLE IF EXISTS `tb_sturesult`;

CREATE TABLE `tb_sturesult` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stuId` varchar(16) DEFAULT NULL,
  `whichLesson` varchar(60) DEFAULT NULL,
  `resSingle` int(11) DEFAULT NULL,
  `resMore` int(11) DEFAULT NULL,
  `resTotal` int(11) DEFAULT NULL,
  `joinTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;

/*Data for the table `tb_sturesult` */

insert  into `tb_sturesult`(`id`,`stuId`,`whichLesson`,`resSingle`,`resMore`,`resTotal`,`joinTime`) values (1,'CN20151201000002','计算机专业英语',50,30,80,'2015-12-01 00:00:00'),(2,'CN20151201000001','物联网体系结构',0,20,20,'2015-12-01 00:00:00'),(4,'CN20151201000001','数据库原理',20,30,50,'2013-01-01 00:00:00'),(12,'CN20151201000001','计算机专业英语',40,60,100,'2015-12-01 00:00:00'),(14,'CN20151225000005','嵌入式系统',40,0,40,'2015-12-01 00:00:00'),(29,'CN20151201000002','接口与通信技术',40,60,100,'2015-12-01 00:00:00'),(30,'CN20151229000006','数据库原理',40,60,100,'2015-12-01 00:00:00'),(37,'CN20151229000007','计算机文化基础',0,0,0,'2015-12-01 00:00:00'),(38,'CN20151229000007','数据库原理',40,60,100,'2015-12-01 00:00:00'),(39,'CN20151229000006','嵌入式系统',0,0,0,'2015-12-01 00:00:00'),(40,'CN20151201000001','数据库原理',0,0,NULL,NULL),(41,'CN20151201000002','接口与通信技术',0,0,NULL,'2015-12-02 11:43:15'),(42,'CN20151201000002','计算机文化基础',40,0,40,'2015-12-02 13:10:12');

/*Table structure for table `tb_taoti` */

DROP TABLE IF EXISTS `tb_taoti`;

CREATE TABLE `tb_taoti` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) DEFAULT NULL,
  `LessonID` int(11) DEFAULT NULL,
  `JoinTime` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

/*Data for the table `tb_taoti` */

insert  into `tb_taoti`(`ID`,`Name`,`LessonID`,`JoinTime`) values (17, '2021年党史团队赛试题1', 29, '2021-12-19 00:00:00'), (19, '2021年党史个人赛试题', 8, '2021-12-19 00:00:00');
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
